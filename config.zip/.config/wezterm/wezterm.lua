local wezterm = require('wezterm')

local theme = require('lua/rose-pine').moon

return {
    colors = theme.colors(),
    window_frame = theme.window_frame(), -- needed only if using fancy tab bar
}
